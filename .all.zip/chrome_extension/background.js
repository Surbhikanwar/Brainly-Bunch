chrome.runtime.onInstalled.addListener(() => {
  console.log("ReviewGuard extension installed.");
});
