# Brainly-Bunch
Team Name- Brainly Bunch
Team Leader's Name - Aanchal Rajawat
Team Member's Name- Aanchal Rajawat,Shurbhi Kanwar
Domain-AI/ML
Problem Statement-AI/ML 01 --->E-commerce platforms are increasingly affected by fake or manipulated product 
reviews, misleading customers and impacting brand trust. There is a need for an 
automated system to identify suspicious review patterns that are not easily caught 
through manual moderation. 
